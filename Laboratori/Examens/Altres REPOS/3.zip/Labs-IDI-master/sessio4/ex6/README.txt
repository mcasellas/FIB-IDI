COM ES RESOL:

Hem de carregar el Homer:

CREAR EL TERRA: 
1. Tot esta a la funcio CarregarTerra() que cridem al CreateBuffers.
2. Tambe hem de pintar el terra, esta a la funcio pintaTerra() que cridem a paint. 
3. Per evitar que es mogui el terra, creem una segona funcio de modelTransform nomes pel terra i a la qual no s'hi aplici la rotaci�.