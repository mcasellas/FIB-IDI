COM ES RESOL:

Hem de carregar el Homer:

1. Declarar al ".h" un float rotacio.
2. A la funcio del teclat, augmentar en M_PI/4 la variable rotacio cada cop que pressionem "R".
3. A la funcio projectTransform afegir; 
transform = glm::rotate(transform, rotacio, glm::vec3(0,1,0));