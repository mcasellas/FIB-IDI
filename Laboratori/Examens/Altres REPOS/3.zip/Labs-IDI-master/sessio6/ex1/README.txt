COM ES RESOL:

View amb angles d'Euler. -> Nom�s canviar la funci� viewTransform.

Tamb� est� fet lo del ratol�.