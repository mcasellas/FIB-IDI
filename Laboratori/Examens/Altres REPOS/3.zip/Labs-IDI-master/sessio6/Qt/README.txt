

ESCENA AMB DOS PATRICIOS:
========================

Com es fa:
1. s'han de fer dues versions pel modelTransform (un per cada patricio).
2. S'ha de calcular tamb� la capsa contenidora de l'escena (hardcodejat).