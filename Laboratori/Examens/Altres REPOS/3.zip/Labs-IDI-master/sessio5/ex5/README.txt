COM ES RESOL:

View amb angles d'Euler. -> Nom�s canviar la funci� viewTransform