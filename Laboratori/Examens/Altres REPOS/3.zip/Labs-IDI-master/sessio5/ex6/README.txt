COM ES RESOL:

INTERACCI� AMB EL RATOL�:

1. funcio mouseMoveEvent
2. Nous valors pel rotate.
3. Actualitzar funci� view per tenir en compte el rotate.
4. Actualitzar funci� createBuffers -> just despr�s de calcular la capsa contenidora del model.