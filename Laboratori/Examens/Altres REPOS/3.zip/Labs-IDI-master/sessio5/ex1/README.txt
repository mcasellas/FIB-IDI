COM ES RESOL:

Fer un resize:
Esta a la funci� resizeGL.