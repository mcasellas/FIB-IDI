COM ES RESOL:

- Calcular capsa contenidora: Funci� calculaCapsaHomer(). S'ha de cridar a aquesta funci� just despr�s d'haver carregat el model. (CreateBuffers).
Jo he calculat nom�s la capsa contenidora del homer per� en cas de voler-la calcular per l'escena sencera, hauria de hardcodejar els valors i fer exactament els mateixos c�lculs.