COM ES RESOL:

PATRICIO:

1 - Funci� per calcular la capsa contenidora.
2 - Funci� carregarPatricio -> tracta els VAO's i VBO's.
3 - A la funci� paint, crear funci� pintaPatricio.