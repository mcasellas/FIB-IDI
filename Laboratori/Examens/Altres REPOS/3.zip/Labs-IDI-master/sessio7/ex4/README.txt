 

 
 4) Canvi posició focus de llum
   Ha de ser la posició (1, 0, -1) en SCA
   
 Anem al vertex shader i canvien la posició.
  --> vec3 posFocus = vec3(1, 0, -1);  // en SCA
