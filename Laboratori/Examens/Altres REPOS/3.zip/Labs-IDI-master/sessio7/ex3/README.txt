


A la funció createBuffers he de canviar;

  glm::vec3 amb(0,0,1);
  glm::vec3 diff(0,0,1);
  glm::vec3 spec(0.2,0.2,0.2);
