# Labs-IDI
##Laboratoris de l'assignatura de IDI. Curs 2016-2017.
 * En general cada sessió té un petit README on està explicat com es fa cada exercici.
 * Està tot organitzat de cara l'examen de lab.
 * La versió correcta del resize està feta als exercicis d'examen.
