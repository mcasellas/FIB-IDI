


1. Carregar els dos Patricios, fer un model transform per cadascun. (Fer els calculs de la capsa del Patricio i de l'escena).
2. Funcio resize de tota la vida -> Canviar el project transform.
3. Angles d'Euler -> Canviar viewTransform.
4. Phong: copiat de la sessio 7, exercici 2. -> Canviar el main del vertex shader.

5. Posicio focus a la càmera, al codi de "phong" treure la multiplicació de la view a posFocus.
6. Color cian -> (0,1,1) -> al vertex shader.

--- Amb el ratolí fer un zoom a l'escena modificant l'angle d'obertura.
7. Funcio mousePressEvent.


Aquesta versió té el màxim del viewport, el resize ben fet i el zoom correcte!!






ACABAR!!!!!