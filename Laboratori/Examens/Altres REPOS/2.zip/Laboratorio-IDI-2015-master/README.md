# IDI-LAB
Aquest repositori conté totes les practiques de openGL de la FIB (Facultat Informatica de Barcelona) del segon quadrimestre de 2015.

- Sistema Operatiu: MacOS

- Llibreries utilitzades:
  - Versio 3.3 de OpenGL
  - Qt5.2
  
# Instalació llibreries:
- Instalar Homebrew (http://brew.sh/)
  - Executar al Terminal:
    - sudo brew install glm
    - sudo brew install glew
    - sudo brew install qt5.2

També podem trobar els pdf's amb les preguntes de cada sessio i les transparencies que ens donen a classe.
